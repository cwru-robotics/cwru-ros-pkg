#!/bin/bash
OPTIND=1

# function to exit when run
# and return when sourced

cleanup()
{
    unset drc_version
    unset gazebo_version
    unset drc_setup_command
    unset drc_setup
    unset gazebo_setup_command
    unset gazebo_setup
    unset no_print
    unset drc_setups
    unset gazebo_setups
}

quit()
{
    cleanup
    if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
	return 1 # script was sourced
    else
	exit 1 # script was run
    fi
}

print_usage()
{
    echo
    echo "drc-version Usage"
    echo "-----------------------"
    echo
    echo "-d <version number>"
    echo -e "\tSet the DRCSim version."
    echo -e "\tIf this isn't provided then will attempt to use DRCSIM_VERSION"
    echo -e "\tEnvironment variable. If that fails will use the latest version"
    echo
    echo "-g <version number>"
    echo -e "\tSet the Gazebo version"
    echo -e "\tIf this isn't provided then will attempt to use GAZEBO_VERSION"
    echo -e "\tEnvironment variable. If that fails will use the latest version"
    echo
    echo "-l"
    echo -e "\tList Gazebo versions"
    echo
    echo "-v"
    echo -e "\tLists the version of Gazebo and DRCSim that are currently in use"
    echo
    echo "-p"
    echo -e "\tDon't print out anything but errors"
    echo
    echo "-h"
    echo -e "\tPrint this help"
    echo
}


error()
{
    echo -e "\033[1;31m$1\033[0m" >&2
}

valid_version()
{
    if [[ $1 =~ ^([0-9]+\.?)*[0-9]+$ ]]; then
	return 0
    else
	return 1
    fi
}

# parse the command line opts
while getopts ":d:g:plhv" opt; do
    case $opt in
	d)
	    if valid_version $OPTARG; then
		drc_version=$OPTARG
	    else
		echo
		error "Invalid version number $OPTARG" >&2
		echo "Versions must start with a number and end with a number"
		echo " and contain only numbers and periods"
		echo
		quit || return $?
	    fi
	;;
	g)
	    if valid_version $OPTARG; then
		gazebo_version=$OPTARG
	    else
		echo
		error "Invalid version number $OPTARG" >&2
		echo "Versions must start with a number and end with a number"
		echo " and contain only numbers and periods"
		echo
		quit || return $?
	    fi
	;;
	p)
	    no_print="true"
	;;
        l)
	    drc_setups=`find /usr/share -maxdepth 2 -path /usr/share/drcsim-'*'/setup.sh | sort`
	    echo
	    echo "DRCSim Versions:"
	    for setup in $drc_setups; do
		echo -e "\t-" `echo "$setup" | sed 's,^/usr/share/drcsim-,,' | sed 's,/setup.sh$,,'`
	    done
	    echo
	    
	    gazebo_setups=`find /usr/share -maxdepth 2 -path /usr/share/gazebo-'*'/setup.sh | sort`
	    echo
	    echo "Gazebo Versions:"
	    for setup in $gazebo_setups; do
		echo -e "\t-" `echo "$setup" | sed 's,^/usr/share/gazebo-,,' | sed 's,/setup.sh$,,'`
	    done
	    echo
	    return 0
	;;
        v)
	    echo
	    echo "Currently Using:"
	    echo -e "\tdrcsim version: $DRCSIM_VERSION"
	    echo -e "\tgazebo version: $GAZEBO_VERSION"
	    echo
	    return 0
        ;;
	h)
	    print_usage
	    cleanup
	    return 0
	;;
	\?)
	    echo
	    error "Invalid option: -$OPTARG" >&2
	    echo
	    print_usage
	    quit || return $?
	;;
	:)
	    echo
	    error "Option -$OPTARG requires an argument." >&2
	    echo
	    print_usage
	    quit || return $?
	;;
    esac
done

# if a drc version wasn't specified
# set it to the wildcard
if [[ -z $drc_version ]]; then
    if [[ ! -z $DRCSIM_VERSION ]]; then
	drc_version=$DRCSIM_VERSION
    else
	drc_version="'*'"
    fi
fi

# if a gazebo version wasn't specified
# set it to the wildcard
if [[ -z $gazebo_version ]]; then
    if [[ ! -z $GAZEBO_VERSION ]]; then
	gazebo_version=$GAZEBO_VERSION
    else
	gazebo_version="'*'"
    fi
fi


gazebo_setup_command="find /usr/share -maxdepth 2 -path /usr/share/gazebo-${gazebo_version}/setup.sh | sort | tail -n 1"
gazebo_setup=`eval $gazebo_setup_command`

if [ -z $gazebo_setup ]; then
    if [ "$gazebo_version" == "'*'" ]; then
	echo
	error "ERROR: Couldn't find a gazebo setup.sh in /usr/share"
	echo
    else
	echo
	error "ERROR: Couldn't find gazebo version $gazebo_version in /usr/share"
	echo
    fi
    quit || return $?
elif [ ! -f $gazebo_setup ]; then
    echo
    error "ERROR: Setup file $setup doesn't exist"
    echo
    quit || return $?
else
    . $gazebo_setup
fi

# this was done to make command substitution work. Probably is a better was of doing this
drc_setup_command="find /usr/share -maxdepth 2 -path /usr/share/drcsim-${drc_version}/setup.sh | sort | tail -n 1"
drc_setup=`eval $drc_setup_command`

if [ -z $drc_setup ]; then
    if [ "$drc_version" == "'*'" ]; then
	echo
	error "ERROR: Couldn't find a drcsim setup.sh in /usr/share"
	echo
    else
	echo
	error "ERROR: Couldn't find drcsim version $drc_version in /usr/share"
	echo
    fi
    quit || return $?
elif [ ! -f $drc_setup ]; then
    echo
    error "ERROR: Setup file $setup doesn't exist"
    echo
    quit || return $?
else
    . $drc_setup
fi

if [ -z $no_print ]; then
    echo
    echo "Using the following versions: "
    if [ "$gazebo_version" == "'*'" ]; then
	gazebo_version=`echo $gazebo_setup | sed 's,^/usr/share/gazebo-,,' | sed 's,/setup.sh$,,'`
	echo -e "\tgazebo: \033[0;32m$gazebo_version (latest)\033[0m"
    else
	echo -e  "\tgazebo: \033[0;32m$gazebo_version\033[0m"
    fi
    if [ "$drc_version" == "'*'" ]; then
	drc_version=`echo $drc_setup | sed 's,^/usr/share/drcsim-,,' | sed 's,/setup.sh$,,'`
	echo -e "\tdrcsim: \033[0;32m$drc_version (latest)\033[0m"
    else
	echo -e "\tdrcsim: \033[0;32m$drc_version\033[0m"
    fi
    echo
else
    if [ "$gazebo_version" == "'*'" ]; then
	gazebo_version=`echo $gazebo_setup | sed 's,^/usr/share/gazebo-,,' | sed 's,/setup.sh$,,'`
    fi
    export GAZEBO_VERSION=$gazebo_version
    if [ "$drc_version" == "'*'" ]; then
	drc_version=`echo $drc_setup | sed 's,^/usr/share/drcsim-,,' | sed 's,/setup.sh$,,'`
    fi
    export DRCSIM_VERSION=$drc_version
fi

cleanup
