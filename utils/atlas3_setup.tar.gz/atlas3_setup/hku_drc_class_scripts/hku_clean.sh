#!/usr/bin/env bash

if [[ -z $ROS_WORKSPACE ]]; then
  export ROS_WORKSPACE=~/ros_workspace

  if [[ -n "$HKU_WORKSPACE" ]]; then
    export ROS_WORKSPACE=$HKU_WORKSPACE
  fi
fi


class_repo_dir=$(find $ROS_WORKSPACE -name '.hku_repository' | xargs -I '{}' dirname {} | head -n 1)
echo "class_repo_dir: $class_repo_dir"

if [[ -z $class_repo_dir ]]; then
  echo "Could not find class repository under $ROS_WORKSPACE"
  echo "Make sure repository exists and then try again"
  return 1
fi

pushd $class_repo_dir/build_scripts/ > /dev/null
source ./hku_clean.sh $@
build_result=$?
popd > /dev/null
return $build_result
